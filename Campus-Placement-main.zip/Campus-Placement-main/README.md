# Campus-Placement
I have created this project during my aiml training
